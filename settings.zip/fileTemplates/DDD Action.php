<?php
#parse("PHP File Header.php")

#if (${NAMESPACE})
namespace ${NAMESPACE};
#end

use Illuminate\Foundation\Http\FormRequest;

class ${NAME} {

     /**
     * @var FormRequest
     */
    protected FormRequest \$request;
    
     public function __construct()
    {
        
    }

    function prepare(FormRequest \$request):self
    {
        \$this->request = \$request;
        
        return \$this;
    }
    
    public function execute()
    {
    
    } 
}